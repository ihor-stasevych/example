<?php
use PHPUnit\Framework\TestCase;

class Success extends TestCase
{
    protected function runTest()
    {
        $this->assertTrue(true);
    }
}
