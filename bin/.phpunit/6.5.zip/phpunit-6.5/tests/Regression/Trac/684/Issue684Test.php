<?php
use PHPUnit\Framework\TestCase;

class Foo_Bar_Issue684Test extends TestCase
{
}
